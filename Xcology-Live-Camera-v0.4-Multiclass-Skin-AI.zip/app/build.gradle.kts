plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xcology.livecamera"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xcology.livecamera"
        minSdk = 29
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0-multiclass-preview"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildTypes { getByName("release") { isMinifyEnabled = false } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.camera:camera-core:1.4.1")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.google.mediapipe:tasks-vision:0.10.32")
}

// Official MediaPipe multi-class model (six classes including face skin and body skin).
// Model is bundled in the APK; no model downloads are required while using the app.
// Download during builds to keep the source repository small.
val downloadSkinModel by tasks.registering {
    val modelFile = file("src/main/assets/selfie_multiclass_256x256.tflite")
    outputs.file(modelFile)
    outputs.upToDateWhen { false }
    doLast {
        if (!modelFile.exists()) {
            modelFile.parentFile.mkdirs()
            val connection = java.net.URI(
                "https://storage.googleapis.com/mediapipe-models/image_segmenter/" +
                "selfie_multiclass_256x256/float32/1/selfie_multiclass_256x256.tflite"
            ).toURL().openConnection().apply {
                connectTimeout = 30_000
                readTimeout = 120_000
            }
            try {
                connection.getInputStream().use { input ->
                    modelFile.outputStream().use { output -> input.copyTo(output) }
                }
            } catch (e: Exception) {
                modelFile.delete()
                throw e
            }
        }
        val digest = java.security.MessageDigest.getInstance("SHA-256")
            .digest(modelFile.readBytes()).joinToString("") { "%02x".format(it) }
        check(digest == "c6748b1253a99067ef71f7e26ca71096cd449baefa8f101900ea23016507e0e0") {
            "The multi-class skin model's SHA-256 was different from the pinned official model"
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadSkinModel) }
